-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: lody_lacko
-- ------------------------------------------------------
-- Server version	11.6.2-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `lody_lacko`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `lody_lacko` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_uca1400_ai_ci */;

USE `lody_lacko`;

--
-- Table structure for table `ceny`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `ceny` (
  `CId` int(11) NOT NULL AUTO_INCREMENT,
  `CTowId` int(11) NOT NULL,
  `CCena` float NOT NULL,
  `CPoprzedniaCena` float NOT NULL,
  `CDataZmiany` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`CId`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ceny`
--

INSERT INTO `ceny` (`CId`, `CTowId`, `CCena`, `CPoprzedniaCena`, `CDataZmiany`) VALUES (1,1,10,8,'2025-04-11 10:50:47'),(2,2,10,10333,'2025-04-11 08:47:30'),(3,3,123,123,'2025-04-11 08:47:36'),(4,4,0.5,0.5,'2025-04-10 13:47:37'),(5,5,23,2,'2025-04-10 13:47:37'),(6,6,6,6,'2025-04-10 14:01:59'),(7,7,923,92,'2025-04-10 14:01:59');

--
-- Table structure for table `dokumenty`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `dokumenty` (
  `DokId` int(11) NOT NULL AUTO_INCREMENT,
  `DokNr` varchar(25) NOT NULL,
  `DokSklepId` int(11) NOT NULL,
  `DokData` datetime NOT NULL DEFAULT current_timestamp(),
  `DokFormaPlatnosci` enum('gotówka','karta','bon') NOT NULL,
  `DokAutorId` int(11) NOT NULL,
  PRIMARY KEY (`DokId`),
  UNIQUE KEY `DokNr` (`DokNr`)
) ENGINE=InnoDB AUTO_INCREMENT=55 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dokumenty`
--

INSERT INTO `dokumenty` (`DokId`, `DokNr`, `DokSklepId`, `DokData`, `DokFormaPlatnosci`, `DokAutorId`) VALUES (1,'WZ/1/2025/1',1,'2025-04-10 15:34:52','karta',1),(2,'WZ/2/2025/1',1,'2025-04-10 15:49:34','karta',1),(3,'WZ/3/2025/1',1,'2025-04-10 15:51:40','karta',1),(4,'WZ/4/2025/1',1,'2025-04-10 15:51:45','bon',1),(5,'WZ/5/2025/1',1,'2025-04-10 15:52:29','gotówka',1),(6,'WZ/6/2025/1',1,'2025-04-10 15:58:42','karta',1),(7,'WZ/7/2025/1',1,'2025-04-11 08:35:56','karta',1),(8,'WZ/8/2025/1',1,'2025-04-11 09:03:31','gotówka',1),(9,'WZ/9/2025/1',1,'2025-04-11 09:13:51','bon',1),(10,'WZ/10/2025/1',1,'2025-04-11 09:13:51','bon',1),(11,'WZ/11/2025/1',1,'2025-04-11 09:13:52','bon',1),(12,'WZ/12/2025/1',1,'2025-04-11 09:14:02','bon',1),(13,'WZ/13/2025/1',1,'2025-04-11 09:23:26','gotówka',1),(14,'WZ/14/2025/1',1,'2025-04-11 09:23:35','karta',1),(15,'WZ/15/2025/1',1,'2025-04-11 09:23:38','bon',1),(16,'WZ/16/2025/1',1,'2025-04-11 09:23:39','bon',1),(17,'WZ/17/2025/1',1,'2025-04-11 09:23:42','bon',1),(18,'WZ/18/2025/1',1,'2025-04-11 09:23:44','bon',1),(19,'WZ/19/2025/1',1,'2025-04-11 09:23:47','bon',1),(20,'WZ/20/2025/1',1,'2025-04-11 09:23:47','bon',1),(21,'WZ/21/2025/1',1,'2025-04-11 09:24:41','bon',1),(22,'WZ/22/2025/1',1,'2025-04-11 09:24:43','bon',1),(23,'WZ/23/2025/1',1,'2025-04-11 09:26:17','bon',1),(24,'WZ/24/2025/1',1,'2025-04-11 09:26:19','bon',1),(25,'WZ/25/2025/1',1,'2025-04-11 09:26:25','gotówka',1),(26,'WZ/26/2025/1',1,'2025-04-11 09:26:28','gotówka',1),(27,'WZ/27/2025/1',1,'2025-04-11 09:27:36','gotówka',1),(28,'WZ/28/2025/1',1,'2025-04-11 09:27:39','gotówka',1),(29,'WZ/29/2025/1',1,'2025-04-11 09:27:59','gotówka',1),(30,'WZ/30/2025/1',1,'2025-04-11 09:42:41','gotówka',1),(31,'WZ/31/2025/1',1,'2025-04-11 09:43:16','gotówka',1),(32,'WZ/32/2025/1',1,'2025-04-11 10:17:27','gotówka',1),(33,'WZ/33/2025/1',1,'2025-04-11 10:17:28','gotówka',1),(34,'WZ/34/2025/1',1,'2025-04-11 10:17:29','gotówka',1),(35,'WZ/35/2025/1',1,'2025-04-11 10:17:29','gotówka',1),(36,'WZ/36/2025/1',1,'2025-04-11 10:17:29','gotówka',1),(37,'WZ/37/2025/1',1,'2025-04-11 10:17:52','gotówka',1),(38,'WZ/38/2025/1',1,'2025-04-11 10:17:56','gotówka',1),(39,'WZ/39/2025/1',1,'2025-04-11 10:18:20','gotówka',1),(40,'WZ/40/2025/1',1,'2025-04-11 10:25:09','gotówka',1),(41,'WZ/41/2025/1',1,'2025-04-11 10:25:14','gotówka',1),(42,'WZ/42/2025/1',1,'2025-04-11 10:25:17','gotówka',1),(43,'WZ/43/2025/1',1,'2025-04-11 10:26:39','gotówka',1),(44,'WZ/44/2025/1',1,'2025-04-11 10:27:13','karta',1),(45,'WZ/45/2025/1',1,'2025-04-11 10:28:03','gotówka',1),(46,'WZ/46/2025/1',1,'2025-04-11 10:29:11','gotówka',1),(47,'WZ/47/2025/1',1,'2025-04-11 10:29:14','gotówka',1),(48,'WZ/48/2025/1',1,'2025-04-11 10:29:15','gotówka',1),(49,'WZ/49/2025/1',1,'2025-04-11 10:29:58','gotówka',1),(50,'WZ/50/2025/1',1,'2025-04-11 10:30:04','gotówka',1),(51,'WZ/51/2025/1',1,'2025-04-11 10:30:07','gotówka',1),(52,'WZ/52/2025/1',1,'2025-04-11 10:30:09','gotówka',1),(53,'WZ/53/2025/1',1,'2025-04-11 10:30:13','gotówka',1),(54,'WZ/54/2025/1',1,'2025-04-11 10:30:47','gotówka',1);

--
-- Table structure for table `dokumentynumeracja`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `dokumentynumeracja` (
  `DokNumSklepId` int(11) NOT NULL,
  `DokNumRok` int(11) NOT NULL,
  `DokNumOstatniNr` int(11) DEFAULT 0,
  PRIMARY KEY (`DokNumSklepId`,`DokNumRok`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dokumentynumeracja`
--

INSERT INTO `dokumentynumeracja` (`DokNumSklepId`, `DokNumRok`, `DokNumOstatniNr`) VALUES (1,2025,54);

--
-- Table structure for table `dokumentypozycje`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `dokumentypozycje` (
  `DokPozId` int(11) NOT NULL AUTO_INCREMENT,
  `DokPozDokId` int(11) NOT NULL,
  `DokPozTowId` int(11) NOT NULL,
  `DokPozTowIlosc` float NOT NULL,
  `DokPozCena` float(10,2) NOT NULL,
  PRIMARY KEY (`DokPozId`),
  KEY `DokPozDokId` (`DokPozDokId`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dokumentypozycje`
--

INSERT INTO `dokumentypozycje` (`DokPozId`, `DokPozDokId`, `DokPozTowId`, `DokPozTowIlosc`, `DokPozCena`) VALUES (1,1,1,1,6.50),(2,2,1,7,45.50),(3,3,1,2,13.00),(4,5,1,8,52.00),(5,6,1,13,84.50),(6,7,1,8,52.00),(7,8,1,5,30.00),(8,9,1,2,132.00),(9,9,3,1,66.00),(10,12,1,2,132.00),(11,12,3,2,132.00),(12,29,1,2,12.00),(13,29,2,2,12.00),(14,31,1,2,12.00),(15,31,2,1,6.00),(16,31,3,1,6.00),(17,54,1,1,8.00);

--
-- Table structure for table `kuwety`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `kuwety` (
  `KuwId` int(11) NOT NULL AUTO_INCREMENT,
  `KuwSmkId` int(11) NOT NULL,
  `KuwRozId` int(11) NOT NULL,
  `KuwPorcje` int(11) NOT NULL,
  `KuwSklId` int(11) DEFAULT NULL,
  `KuwDataZmiany` datetime DEFAULT current_timestamp(),
  `KuwStatus` tinyint(1) NOT NULL DEFAULT 1,
  `KuwStatusZamowienia` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`KuwId`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kuwety`
--

INSERT INTO `kuwety` (`KuwId`, `KuwSmkId`, `KuwRozId`, `KuwPorcje`, `KuwSklId`, `KuwDataZmiany`, `KuwStatus`, `KuwStatusZamowienia`) VALUES (1,1,1,37,1,'2025-04-10 13:53:25',1,1),(2,4,1,87,1,'2025-04-11 09:08:26',1,1),(3,2,1,86,1,'2025-04-11 09:08:31',1,1);

--
-- Table structure for table `kuwetystatuszamowienia`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `kuwetystatuszamowienia` (
  `KuwStatZamId` int(11) NOT NULL AUTO_INCREMENT,
  `KuwStatZamNazwa` varchar(255) NOT NULL,
  `KuwStatZamDataZmiany` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`KuwStatZamId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kuwetystatuszamowienia`
--


--
-- Table structure for table `liczniki`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `liczniki` (
  `LId` int(11) NOT NULL AUTO_INCREMENT,
  `LNazwa` varchar(255) NOT NULL,
  `LWielkosc` float NOT NULL,
  `LPoziom` float NOT NULL,
  PRIMARY KEY (`LId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `liczniki`
--


--
-- Table structure for table `rcp`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `rcp` (
  `RCPId` int(11) NOT NULL AUTO_INCREMENT,
  `RCPStartZmiany` datetime DEFAULT NULL,
  `RCPKoniecZmiany` datetime DEFAULT NULL,
  `RCPUzId` int(11) NOT NULL,
  PRIMARY KEY (`RCPId`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rcp`
--

INSERT INTO `rcp` (`RCPId`, `RCPStartZmiany`, `RCPKoniecZmiany`, `RCPUzId`) VALUES (1,'2025-04-10 13:51:35','2025-04-10 14:17:56',1),(2,'2025-04-10 15:34:06','2025-04-10 15:49:09',1),(3,'2025-04-10 15:49:11','2025-04-10 15:49:14',1),(4,'2025-04-10 15:49:16','2025-04-10 15:51:52',1),(5,'2025-04-10 15:51:56','2025-04-10 15:52:00',1),(6,'2025-04-10 15:52:09','2025-04-10 15:52:11',1),(7,'2025-04-10 15:52:13','2025-04-10 15:52:17',1),(8,'2025-04-10 15:52:18','2025-04-11 08:09:10',1),(9,'2025-04-11 08:09:11','2025-04-11 08:36:12',1),(10,'2025-04-11 08:36:13',NULL,1);

--
-- Table structure for table `rozmiary`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `rozmiary` (
  `RozId` int(11) NOT NULL AUTO_INCREMENT,
  `RozNazwa` varchar(255) NOT NULL,
  `RozPojemnosc` int(11) NOT NULL,
  `RozDataZmiany` datetime NOT NULL DEFAULT current_timestamp(),
  `RozStatus` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`RozId`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rozmiary`
--

INSERT INTO `rozmiary` (`RozId`, `RozNazwa`, `RozPojemnosc`, `RozDataZmiany`, `RozStatus`) VALUES (1,'Duża kuweta',90,'2025-04-10 13:53:19',1),(2,'Kuweta Mała',75,'2025-04-11 10:36:32',1);

--
-- Table structure for table `sklepy`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `sklepy` (
  `SklId` int(11) NOT NULL AUTO_INCREMENT,
  `SklNazwa` varchar(255) NOT NULL,
  `SklUlica` varchar(255) DEFAULT NULL,
  `SklNumer` varchar(255) DEFAULT NULL,
  `SklKod` varchar(255) DEFAULT NULL,
  `SklMiejscowosc` varchar(255) DEFAULT NULL,
  `SklPojemnosc` int(11) NOT NULL,
  `SklDataZmiany` datetime NOT NULL DEFAULT current_timestamp(),
  `SklStatus` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`SklId`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sklepy`
--

INSERT INTO `sklepy` (`SklId`, `SklNazwa`, `SklUlica`, `SklNumer`, `SklKod`, `SklMiejscowosc`, `SklPojemnosc`, `SklDataZmiany`, `SklStatus`) VALUES (1,'Sklep 1','Prusa','33','30-117','Kraków',20,'2025-04-10 13:41:51',1),(2,'Kraków','','','','',2,'2025-04-11 10:44:02',1);

--
-- Table structure for table `smaki`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `smaki` (
  `SmkId` int(11) NOT NULL AUTO_INCREMENT,
  `SmkNazwa` varchar(255) NOT NULL,
  `SmkDataZmiany` datetime NOT NULL DEFAULT current_timestamp(),
  `SmkKolor` varchar(255) DEFAULT NULL,
  `SmkTekstKolor` varchar(255) DEFAULT NULL,
  `SmkStatus` tinyint(1) NOT NULL DEFAULT 1,
  `SmkTowId` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`SmkId`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `smaki`
--

INSERT INTO `smaki` (`SmkId`, `SmkNazwa`, `SmkDataZmiany`, `SmkKolor`, `SmkTekstKolor`, `SmkStatus`, `SmkTowId`) VALUES (1,'Czekolada','2025-04-10 13:53:06','#470000','#ffffff',1,1),(2,'Truskawka','2025-04-11 09:07:53','#ff0000','#ffffff',1,1),(3,'Banan','2025-04-11 09:08:07','#e6d200','#000000',1,1),(4,'Mięta','2025-04-11 09:08:18','#00ffd5','#000000',1,1);

--
-- Table structure for table `towary`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `towary` (
  `TowId` int(11) NOT NULL AUTO_INCREMENT,
  `TowNazwa` varchar(255) NOT NULL,
  `TowCenaId` int(11) NOT NULL,
  `TowDataZmiany` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`TowId`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `towary`
--

INSERT INTO `towary` (`TowId`, `TowNazwa`, `TowCenaId`, `TowDataZmiany`) VALUES (1,'Lody Rzemieślnicze',1,'2025-04-10 13:44:19'),(2,'Kawa Mrożona',2,'2025-04-10 13:44:19'),(3,'Granita',3,'2025-04-10 13:44:19'),(4,'Polewa / Posypka',4,'2025-04-10 13:44:19'),(5,'Bita Śmietana',5,'2025-04-10 13:44:19'),(6,'Włoskie Małe',6,'2025-04-10 14:00:57'),(7,'Włoskie Duże',7,'2025-04-10 14:00:57');

--
-- Table structure for table `ulozenie`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `ulozenie` (
  `UId` int(11) NOT NULL AUTO_INCREMENT,
  `UKuw1Id` int(11) DEFAULT NULL,
  `UKuw2Id` int(11) DEFAULT NULL,
  `UKuw3Id` int(11) DEFAULT NULL,
  `UKuw4Id` int(11) DEFAULT NULL,
  `UKuw5Id` int(11) DEFAULT NULL,
  `UKuw6Id` int(11) DEFAULT NULL,
  `UKuw7Id` int(11) DEFAULT NULL,
  `UKuw8Id` int(11) DEFAULT NULL,
  `UKuw9Id` int(11) DEFAULT NULL,
  `UKuw10Id` int(11) DEFAULT NULL,
  `USklId` int(11) NOT NULL,
  `UDataZmiany` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`UId`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ulozenie`
--

INSERT INTO `ulozenie` (`UId`, `UKuw1Id`, `UKuw2Id`, `UKuw3Id`, `UKuw4Id`, `UKuw5Id`, `UKuw6Id`, `UKuw7Id`, `UKuw8Id`, `UKuw9Id`, `UKuw10Id`, `USklId`, `UDataZmiany`) VALUES (1,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,3,1,'2025-04-11 10:04:23'),(2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,'2025-04-11 10:44:02');

--
-- Table structure for table `uzytkownicy`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `uzytkownicy` (
  `UzId` int(11) NOT NULL AUTO_INCREMENT,
  `UzImie` varchar(255) NOT NULL,
  `UzNazwisko` varchar(255) NOT NULL,
  `UzLogin` varchar(255) DEFAULT NULL,
  `UzHaslo` varchar(255) DEFAULT NULL,
  `UzPIN` varchar(255) DEFAULT NULL,
  `UzStatus` tinyint(1) NOT NULL DEFAULT 1,
  `UzStawkaGodzinowa` float DEFAULT 0,
  `UzDataZmiany` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`UzId`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `uzytkownicy`
--

INSERT INTO `uzytkownicy` (`UzId`, `UzImie`, `UzNazwisko`, `UzLogin`, `UzHaslo`, `UzPIN`, `UzStatus`, `UzStawkaGodzinowa`, `UzDataZmiany`) VALUES (1,'Mateusz','Gancarz','mati','$2b$10$Tr2/yuEU3cAiKV8e76l0IOtTTgkKd4n4EK5K4GEW/Cjm/TORwsY.6','$2b$10$yKACm1OWibj6Bj1u4DQqTeG6hlrXbeeyX.NKlNOks0.4nhorz.0QW',1,123,'2025-04-10 12:00:05'),(2,'Sławek','Kaszuba','sk','$2b$10$dHBKBU8FjbnBAB61xAgya.4HpSHBh/5THYoqQ8Y6riWXQ74rTnctC','$2b$10$ouZimn2Jd.u9Tq8RmyeH6O2FV5pt3SKGOp0xZG04.7pF5tJXUMefa',1,12,'2025-04-11 10:39:21');

--
-- Table structure for table `uzytkownicysklep`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `uzytkownicysklep` (
  `UzSklId` int(11) NOT NULL AUTO_INCREMENT,
  `UzSklUzId` int(11) NOT NULL,
  `UzSklSklId` int(11) NOT NULL,
  PRIMARY KEY (`UzSklId`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `uzytkownicysklep`
--

INSERT INTO `uzytkownicysklep` (`UzSklId`, `UzSklUzId`, `UzSklSklId`) VALUES (1,1,1);

--
-- Table structure for table `zamowienia`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `zamowienia` (
  `ZamId` int(11) NOT NULL AUTO_INCREMENT,
  `ZamKuwId` int(11) DEFAULT NULL,
  `ZamSmkId` int(11) DEFAULT NULL,
  `ZamSklId` int(11) NOT NULL,
  `ZamStatus` tinyint(1) NOT NULL DEFAULT 1,
  `ZamData` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`ZamId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `zamowienia`
--


--
-- Dumping routines for database 'lody_lacko'
--
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'IGNORE_SPACE,STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `rejestruj_zmiane`(IN user_id INT)
BEGIN
        DECLARE v_last_id INT;
        DECLARE v_end_time DATETIME;
        
        SELECT RCPId, RCPKoniecZmiany INTO v_last_id, v_end_time
        FROM rcp 
        WHERE RCPUzId = user_id
        ORDER BY RCPStartZmiany DESC 
        LIMIT 1;
        
        IF v_last_id IS NULL OR v_end_time IS NOT NULL THEN
            INSERT INTO rcp (RCPUzId, RCPStartZmiany, RCPKoniecZmiany)
            VALUES (user_id, NOW(), NULL);
        ELSE
            UPDATE rcp 
            SET RCPKoniecZmiany = NOW()
            WHERE RCPId = v_last_id;
        END IF;
    END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-04-13 21:35:40
