-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: lody_lacko
-- ------------------------------------------------------
-- Server version	11.6.2-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `lody_lacko`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `lody_lacko` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_uca1400_ai_ci */;

USE `lody_lacko`;

--
-- Table structure for table `ceny`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `ceny` (
  `CId` int(11) NOT NULL AUTO_INCREMENT,
  `CTowId` int(11) NOT NULL,
  `CCena` float NOT NULL,
  `CPoprzedniaCena` float NOT NULL,
  `CDataZmiany` datetime NOT NULL DEFAULT current_timestamp(),
  `CSklepId` int(11) NOT NULL,
  PRIMARY KEY (`CId`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ceny`
--

INSERT INTO `ceny` (`CId`, `CTowId`, `CCena`, `CPoprzedniaCena`, `CDataZmiany`, `CSklepId`) VALUES (1,1,8,6,'2025-05-08 15:10:35',1),(2,2,6,0,'2025-04-24 09:20:44',1),(3,3,9,0,'2025-04-24 09:20:24',1),(4,4,8,0,'2025-04-25 11:44:00',1),(5,5,10,0,'2025-04-25 11:44:21',1),(6,6,0.5,0,'2025-04-24 09:21:51',1),(7,7,2,2,'2025-05-05 16:28:46',1),(8,8,7,0,'2025-05-08 14:43:20',1),(9,1,101,10,'2025-05-08 15:01:02',6),(10,2,6,0,'2025-05-08 15:00:13',6),(11,3,9,0,'2025-05-08 15:00:13',6),(12,4,8,0,'2025-05-08 15:00:13',6),(13,5,10,0,'2025-05-08 15:00:13',6),(14,6,0.5,0,'2025-05-08 15:00:13',6),(15,7,2,0,'2025-05-08 15:00:13',6),(16,8,111,7,'2025-05-08 15:11:37',6),(17,1,10,8,'2025-05-08 15:40:46',2),(18,2,6,0,'2025-05-08 15:35:02',2),(19,3,9,0,'2025-05-08 15:35:03',2),(20,4,20,8,'2025-05-08 15:46:54',2),(21,5,12,10,'2025-05-08 15:35:43',2),(22,6,0.5,0,'2025-05-08 15:35:06',2),(23,7,2,2,'2025-05-08 15:35:08',2),(24,8,1000,7,'2025-05-08 15:39:44',2);

--
-- Table structure for table `dokumenty`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `dokumenty` (
  `DokId` int(11) NOT NULL AUTO_INCREMENT,
  `DokNr` varchar(25) NOT NULL,
  `DokSklepId` int(11) NOT NULL,
  `DokData` datetime NOT NULL DEFAULT current_timestamp(),
  `DokFormaPlatnosci` enum('gotówka','karta','bon') NOT NULL,
  `DokAutorId` int(11) NOT NULL,
  `DokDatazmiany` datetime NOT NULL DEFAULT current_timestamp(),
  `DokTyp` int(11) NOT NULL,
  PRIMARY KEY (`DokId`),
  UNIQUE KEY `DokNr` (`DokNr`)
) ENGINE=InnoDB AUTO_INCREMENT=84 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dokumenty`
--

INSERT INTO `dokumenty` (`DokId`, `DokNr`, `DokSklepId`, `DokData`, `DokFormaPlatnosci`, `DokAutorId`, `DokDatazmiany`, `DokTyp`) VALUES (1,'WZ/1/2025/1',1,'2025-04-24 09:22:24','gotówka',1,'2025-04-24 14:59:35',1),(2,'WZ/2/2025/1',1,'2025-04-24 09:22:32','bon',1,'2025-04-24 14:59:35',1),(3,'WZ/3/2025/1',1,'2025-04-24 13:27:23','gotówka',1,'2025-04-24 15:01:19',1),(4,'WZ/4/2025/1',1,'2025-04-24 15:01:48','karta',1,'2025-04-24 15:04:21',1),(5,'WZ/5/2025/1',1,'2025-04-24 15:04:34','karta',1,'2025-04-24 15:04:39',1),(6,'WZ/6/2025/1',1,'2025-04-24 15:05:15','gotówka',1,'2025-04-24 15:05:38',1),(7,'WZ/1/2025/2',2,'2025-04-24 15:05:24','karta',1,'2025-04-24 15:05:24',1),(8,'WZ/7/2025/1',1,'2025-04-24 15:10:49','bon',1,'2025-04-24 15:10:53',1),(9,'WZ/8/2025/1',1,'2025-04-24 15:12:57','bon',1,'2025-04-24 15:13:11',1),(10,'WZ/9/2025/1',1,'2025-04-24 15:18:01','bon',1,'2025-04-24 15:18:08',1),(11,'WZ/10/2025/1',1,'2025-04-25 09:27:08','gotówka',1,'2025-04-25 09:27:08',1),(12,'WZ/11/2025/1',1,'2025-04-28 09:37:52','bon',1,'2025-04-28 09:37:52',1),(13,'WZ/12/2025/1',1,'2025-05-05 16:43:15','gotówka',1,'2025-05-05 16:43:15',1),(14,'WZ/13/2025/1',1,'2025-05-05 22:59:22','gotówka',1,'2025-05-05 22:59:22',1),(17,'WZ/14/2025/1',1,'2025-05-06 22:22:03','gotówka',1,'2025-05-06 22:22:03',1),(18,'WZ/15/2025/1',1,'2025-05-06 22:22:19','gotówka',1,'2025-05-06 22:22:19',1),(19,'WZ/16/2025/1',1,'2025-05-06 22:22:35','gotówka',1,'2025-05-06 22:22:35',1),(20,'WZ/17/2025/1',1,'2025-05-06 22:47:18','gotówka',1,'2025-05-06 22:47:18',1),(21,'WZ/18/2025/1',1,'2025-05-06 22:47:22','gotówka',1,'2025-05-06 22:47:22',1),(22,'WZ/19/2025/1',1,'2025-05-06 22:55:35','karta',1,'2025-05-06 22:55:35',1),(23,'WZ/20/2025/1',1,'2025-05-06 22:55:44','bon',1,'2025-05-06 22:55:44',1),(24,'WZ/21/2025/1',1,'2025-05-06 22:55:57','karta',1,'2025-05-06 22:55:57',1),(25,'WZ/22/2025/1',1,'2025-05-06 23:10:29','gotówka',1,'2025-05-06 23:10:29',1),(26,'WZ/23/2025/1',1,'2025-05-06 23:10:43','gotówka',1,'2025-05-06 23:10:43',1),(27,'WZ/24/2025/1',1,'2025-05-06 23:10:58','gotówka',1,'2025-05-06 23:10:58',1),(28,'WZ/25/2025/1',1,'2025-05-06 23:11:07','gotówka',1,'2025-05-06 23:11:07',1),(29,'WZ/26/2025/1',1,'2025-05-06 23:12:38','gotówka',1,'2025-05-06 23:12:38',1),(30,'WZ/27/2025/1',1,'2025-05-06 23:12:53','gotówka',1,'2025-05-06 23:12:53',1),(31,'WZ/28/2025/1',1,'2025-05-06 23:12:57','gotówka',1,'2025-05-06 23:12:57',1),(32,'WZ/29/2025/1',1,'2025-05-06 23:13:06','gotówka',1,'2025-05-06 23:13:06',1),(33,'WZ/30/2025/1',1,'2025-05-06 23:13:06','gotówka',1,'2025-05-06 23:13:06',1),(34,'WZ/31/2025/1',1,'2025-05-06 23:34:25','gotówka',1,'2025-05-06 23:34:25',1),(35,'WZ/32/2025/1',1,'2025-05-06 23:34:33','gotówka',1,'2025-05-06 23:34:33',1),(36,'WZ/33/2025/1',1,'2025-05-06 23:36:54','gotówka',1,'2025-05-06 23:36:54',1),(37,'WZ/34/2025/1',1,'2025-05-06 23:37:17','gotówka',1,'2025-05-06 23:37:17',1),(38,'WZ/35/2025/1',1,'2025-05-06 23:38:48','gotówka',1,'2025-05-06 23:38:48',1),(39,'WZ/36/2025/1',1,'2025-05-06 23:39:20','gotówka',1,'2025-05-06 23:39:20',1),(40,'WZ/37/2025/1',1,'2025-05-06 23:39:38','gotówka',1,'2025-05-06 23:39:38',1),(41,'WZ/38/2025/1',1,'2025-05-06 23:40:13','gotówka',1,'2025-05-06 23:40:13',1),(42,'WZ/39/2025/1',1,'2025-05-06 23:40:34','gotówka',1,'2025-05-06 23:40:34',1),(43,'WZ/40/2025/1',1,'2025-05-06 23:40:39','gotówka',1,'2025-05-06 23:40:39',1),(44,'WZ/41/2025/1',1,'2025-05-06 23:40:58','gotówka',1,'2025-05-06 23:40:58',1),(45,'WZ/42/2025/1',1,'2025-05-06 23:42:27','bon',1,'2025-05-06 23:44:29',1),(46,'WZ/43/2025/1',1,'2025-05-07 00:09:13','gotówka',1,'2025-05-07 00:09:13',1),(47,'WZ/44/2025/1',1,'2025-05-07 00:10:51','gotówka',1,'2025-05-07 00:10:51',1),(48,'WZ/45/2025/1',1,'2025-05-07 00:11:13','gotówka',1,'2025-05-07 00:11:13',1),(49,'WZ/46/2025/1',1,'2025-05-07 00:12:54','gotówka',1,'2025-05-07 00:12:54',1),(50,'WZ/47/2025/1',1,'2025-05-07 00:13:13','gotówka',1,'2025-05-07 00:13:13',1),(51,'WZ/48/2025/1',1,'2025-05-07 00:14:08','gotówka',1,'2025-05-07 00:14:08',1),(52,'WZ/49/2025/1',1,'2025-05-07 00:14:16','gotówka',1,'2025-05-07 00:14:16',1),(53,'WZ/50/2025/1',1,'2025-05-07 00:27:19','gotówka',1,'2025-05-07 00:27:19',1),(54,'WZ/51/2025/1',1,'2025-05-07 00:27:58','gotówka',1,'2025-05-07 00:27:58',1),(55,'WZ/52/2025/1',1,'2025-05-07 00:28:00','gotówka',1,'2025-05-07 00:28:00',1),(56,'WZ/1/2025/3',3,'2025-05-07 00:32:55','gotówka',1,'2025-05-07 00:32:55',1),(57,'WZ/2/2025/3',3,'2025-05-07 00:33:10','karta',1,'2025-05-07 00:33:10',1),(58,'WZ/3/2025/3',3,'2025-05-07 00:33:24','gotówka',1,'2025-05-07 00:33:24',1),(59,'WZ/4/2025/3',3,'2025-05-07 08:15:48','gotówka',1,'2025-05-07 08:15:48',1),(60,'WZ/5/2025/3',3,'2025-05-07 08:17:06','gotówka',1,'2025-05-07 08:17:06',1),(61,'WZ/53/2025/1',1,'2025-05-07 09:09:26','gotówka',1,'2025-05-07 09:09:26',1),(62,'WZ/54/2025/1',1,'2025-05-07 09:13:25','gotówka',1,'2025-05-07 09:13:25',1),(63,'WZ/55/2025/1',1,'2025-05-07 09:13:31','gotówka',1,'2025-05-07 09:13:31',1),(64,'WZ/56/2025/1',1,'2025-05-07 09:13:36','gotówka',1,'2025-05-07 09:13:36',1),(65,'WZ/57/2025/1',1,'2025-05-07 12:53:36','gotówka',1,'2025-05-07 12:53:36',1),(66,'WZ/58/2025/1',1,'2025-05-07 12:53:38','gotówka',1,'2025-05-07 12:53:38',1),(67,'WZ/59/2025/1',1,'2025-05-07 12:53:45','gotówka',1,'2025-05-07 12:53:45',1),(68,'WZ/60/2025/1',1,'2025-05-07 12:53:47','gotówka',1,'2025-05-07 12:53:47',1),(69,'WZ/61/2025/1',1,'2025-05-07 12:53:50','gotówka',1,'2025-05-07 12:53:50',1),(70,'WZ/62/2025/1',1,'2025-05-07 12:53:56','karta',1,'2025-05-07 12:53:56',1),(71,'WZ/63/2025/1',1,'2025-05-07 12:53:58','gotówka',1,'2025-05-07 12:53:58',1),(72,'WZ/64/2025/1',1,'2025-05-07 12:54:01','gotówka',1,'2025-05-07 12:54:01',1),(73,'WZ/65/2025/1',1,'2025-05-07 12:54:04','gotówka',1,'2025-05-07 12:54:04',1),(74,'WZ/66/2025/1',1,'2025-05-07 12:54:27','bon',1,'2025-05-07 12:54:27',1),(75,'WZ/67/2025/1',1,'2025-05-07 13:04:50','karta',1,'2025-05-07 13:04:50',1),(76,'WZ/68/2025/1',1,'2025-05-07 13:05:56','karta',1,'2025-05-07 13:05:56',1),(77,'WZ/69/2025/1',1,'2025-05-07 13:06:39','karta',1,'2025-05-07 13:06:39',1),(78,'WZ/70/2025/1',1,'2025-05-07 13:06:49','gotówka',1,'2025-05-07 13:06:49',1),(79,'WZ/6/2025/3',3,'2025-05-08 14:03:43','gotówka',1,'2025-05-08 14:03:43',1),(81,'WZ/2/2025/2',2,'2025-05-08 14:05:24','gotówka',1,'2025-05-08 14:05:24',1),(82,'WZ/3/2025/2',2,'2025-05-08 14:16:33','karta',1,'2025-05-08 14:16:33',1),(83,'WZ/4/2025/2',2,'2025-05-08 15:47:09','gotówka',1,'2025-05-08 15:47:09',1);

--
-- Table structure for table `dokumentynumeracja`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `dokumentynumeracja` (
  `DokNumSklepId` int(11) NOT NULL,
  `DokNumRok` int(11) NOT NULL,
  `DokNumTyp` varchar(10) NOT NULL,
  `DokNumOstatniNr` int(11) DEFAULT 0,
  PRIMARY KEY (`DokNumSklepId`,`DokNumRok`,`DokNumTyp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dokumentynumeracja`
--

INSERT INTO `dokumentynumeracja` (`DokNumSklepId`, `DokNumRok`, `DokNumTyp`, `DokNumOstatniNr`) VALUES (1,2025,'1',70),(1,2025,'2',8),(2,2025,'1',4),(3,2025,'1',6);

--
-- Table structure for table `dokumentypozycje`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `dokumentypozycje` (
  `DokPozId` int(11) NOT NULL AUTO_INCREMENT,
  `DokPozDokId` int(11) NOT NULL,
  `DokPozTowId` int(11) DEFAULT NULL,
  `DokPozPozostalyTowId` int(11) DEFAULT NULL,
  `DokPozTowIlosc` float NOT NULL,
  `DokPozCena` float(10,2) NOT NULL,
  PRIMARY KEY (`DokPozId`)
) ENGINE=InnoDB AUTO_INCREMENT=121 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dokumentypozycje`
--

INSERT INTO `dokumentypozycje` (`DokPozId`, `DokPozDokId`, `DokPozTowId`, `DokPozPozostalyTowId`, `DokPozTowIlosc`, `DokPozCena`) VALUES (1,1,NULL,6,5,2.50),(2,2,NULL,7,4,8.00),(3,3,NULL,6,1,0.50),(4,3,NULL,7,1,2.00),(5,4,NULL,7,1,2.00),(6,5,NULL,6,2,1.00),(7,6,NULL,7,3,6.00),(8,6,NULL,6,5,2.50),(9,7,NULL,6,2,1.00),(10,7,NULL,7,2,4.00),(11,7,NULL,2,4,24.00),(12,8,NULL,7,16,32.00),(13,9,6,1,6,36.00),(14,9,1,1,5,30.00),(15,9,5,1,5,30.00),(16,10,NULL,2,4,24.00),(17,11,5,1,5,30.00),(18,12,5,1,1,6.00),(19,13,NULL,7,5,10.00),(20,14,NULL,2,1,6.00),(21,17,NULL,7,2,4.00),(22,18,NULL,2,2,12.00),(23,19,NULL,2,5,30.00),(24,20,NULL,2,4,24.00),(25,21,NULL,3,7,63.00),(26,22,NULL,4,5,40.00),(27,23,NULL,3,7,63.00),(28,24,NULL,4,2,16.00),(29,25,NULL,2,2,12.00),(30,26,NULL,3,2,18.00),(31,27,NULL,2,2,12.00),(32,28,NULL,2,2,12.00),(33,29,NULL,2,2,12.00),(34,30,NULL,2,2,12.00),(35,31,NULL,3,1,9.00),(36,32,NULL,3,1,9.00),(37,34,NULL,2,2,12.00),(38,35,NULL,3,4,36.00),(39,36,NULL,2,1,6.00),(40,37,NULL,3,1,9.00),(41,38,NULL,2,1,6.00),(42,39,NULL,2,1,6.00),(43,40,NULL,2,1,6.00),(44,41,NULL,2,1,6.00),(45,42,NULL,2,1,6.00),(46,43,NULL,3,1,9.00),(47,44,NULL,2,2,12.00),(48,45,NULL,2,1,6.00),(49,46,NULL,2,1,6.00),(50,47,NULL,2,5,30.00),(51,48,NULL,2,3,18.00),(52,49,NULL,2,1,6.00),(53,50,NULL,2,1,6.00),(54,51,NULL,2,2,12.00),(55,52,NULL,3,2,18.00),(56,53,NULL,2,2,12.00),(57,54,NULL,3,1,9.00),(58,55,NULL,2,1,6.00),(59,56,NULL,2,7,42.00),(60,57,NULL,2,10,60.00),(61,58,NULL,3,5,45.00),(62,59,NULL,2,2,12.00),(63,60,NULL,2,2,12.00),(64,61,8,1,10,60.00),(65,62,8,1,1,6.00),(66,63,NULL,2,1,6.00),(67,64,8,1,2,12.00),(68,64,NULL,2,2,12.00),(69,65,9,1,1,6.00),(70,66,17,1,2,12.00),(71,67,17,1,2,12.00),(72,68,18,1,2,12.00),(73,69,NULL,2,1,6.00),(74,70,19,1,1,6.00),(75,70,14,1,1,6.00),(76,70,13,1,1,6.00),(77,70,18,1,1,6.00),(78,70,17,1,1,6.00),(79,70,12,1,1,6.00),(80,70,11,1,1,6.00),(81,70,16,1,1,6.00),(82,70,15,1,1,6.00),(83,70,9,1,1,6.00),(84,71,19,1,2,12.00),(85,72,15,1,9,54.00),(86,73,17,1,1,6.00),(87,73,12,1,1,6.00),(88,73,13,1,1,6.00),(89,73,18,1,1,6.00),(90,74,19,1,1,6.00),(91,74,14,1,1,6.00),(92,74,13,1,1,6.00),(93,74,18,1,1,6.00),(94,74,17,1,1,6.00),(95,74,12,1,1,6.00),(96,74,11,1,1,6.00),(97,74,16,1,1,6.00),(98,74,15,1,1,6.00),(99,74,9,1,1,6.00),(100,75,NULL,2,20,120.00),(101,76,NULL,2,7,42.00),(102,76,NULL,3,6,54.00),(103,77,NULL,2,4,24.00),(104,77,NULL,3,6,54.00),(105,78,NULL,2,1,6.00),(106,78,NULL,3,1,9.00),(107,79,24,1,3,18.00),(108,79,NULL,7,2,4.00),(109,79,NULL,6,2,1.00),(110,79,NULL,2,1,6.00),(111,79,NULL,3,1,9.00),(112,79,NULL,4,1,8.00),(113,79,NULL,5,1,10.00),(114,81,NULL,6,2,1.00),(115,81,NULL,7,2,4.00),(116,81,NULL,2,1,6.00),(117,81,NULL,3,1,9.00),(118,82,2,1,10,60.00),(119,83,NULL,4,1,20.00),(120,83,NULL,2,4,24.00);

--
-- Table structure for table `dokumentytyp`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `dokumentytyp` (
  `DokTypId` int(11) NOT NULL AUTO_INCREMENT,
  `DokTypNazwa` varchar(255) NOT NULL,
  `DokTypSymbol` varchar(255) NOT NULL,
  PRIMARY KEY (`DokTypId`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dokumentytyp`
--

INSERT INTO `dokumentytyp` (`DokTypId`, `DokTypNazwa`, `DokTypSymbol`) VALUES (1,'Wydanie Zewnętrzne','WZ'),(2,'Zamówienie','ZAM');

--
-- Table structure for table `kuwety`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `kuwety` (
  `KuwId` int(11) NOT NULL AUTO_INCREMENT,
  `KuwSmkId` int(11) NOT NULL,
  `KuwRozId` int(11) NOT NULL,
  `KuwPorcje` int(11) NOT NULL,
  `KuwSklId` int(11) DEFAULT NULL,
  `KuwStatus` tinyint(1) NOT NULL DEFAULT 1,
  `KuwStatusZamowienia` tinyint(1) NOT NULL DEFAULT 1,
  `KuwDataZmiany` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`KuwId`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kuwety`
--

INSERT INTO `kuwety` (`KuwId`, `KuwSmkId`, `KuwRozId`, `KuwPorcje`, `KuwSklId`, `KuwStatus`, `KuwStatusZamowienia`, `KuwDataZmiany`) VALUES (1,1,2,95,1,0,1,'2025-05-10 11:00:00'),(2,2,2,90,2,1,1,'2025-04-24 15:12:18'),(3,2,2,100,2,1,1,'2025-04-24 15:12:18'),(4,2,2,100,2,1,1,'2025-04-24 15:12:18'),(5,2,2,89,1,0,1,'2025-04-30 08:44:46'),(6,2,2,94,1,0,1,'2025-04-30 08:44:48'),(7,2,2,100,1,0,1,'2025-04-30 08:44:50'),(8,1,1,77,1,1,1,'2025-05-07 09:09:16'),(9,1,2,97,1,1,1,'2025-04-25 09:09:59'),(10,1,1,90,1,1,1,'2025-05-08 12:00:31'),(11,2,1,88,1,1,1,'2025-05-07 12:52:41'),(12,3,1,87,1,1,1,'2025-05-07 12:52:41'),(13,4,1,87,1,1,1,'2025-05-07 12:52:41'),(14,5,1,88,1,1,1,'2025-05-07 12:52:41'),(15,6,1,79,1,1,1,'2025-05-07 12:52:41'),(16,7,1,88,1,1,1,'2025-05-07 12:52:41'),(17,8,1,83,1,1,1,'2025-05-07 12:52:41'),(18,9,1,85,1,1,1,'2025-05-07 12:52:41'),(19,10,1,86,1,1,1,'2025-05-07 12:52:41'),(20,9,1,90,2,1,1,'2025-05-08 11:58:10'),(21,1,2,100,2,1,1,'2025-05-08 12:09:46'),(22,8,2,100,1,1,1,'2025-05-08 12:07:25'),(23,7,2,100,6,1,1,'2025-05-08 15:11:11'),(24,5,1,87,3,1,1,'2025-05-08 12:10:34'),(25,2,3,200,1,1,1,'2025-05-08 14:02:06'),(26,7,1,90,2,1,1,'2025-05-08 15:40:07');

--
-- Table structure for table `kuwetystatuszamowienia`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `kuwetystatuszamowienia` (
  `KuwStatZamId` int(11) NOT NULL AUTO_INCREMENT,
  `KuwStatZamNazwa` varchar(255) NOT NULL,
  `KuwStatZamDataZmiany` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`KuwStatZamId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kuwetystatuszamowienia`
--


--
-- Table structure for table `liczniki`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `liczniki` (
  `LId` int(11) NOT NULL AUTO_INCREMENT,
  `LSklId` int(11) NOT NULL,
  `LTyp` int(11) NOT NULL,
  `LWartosc` int(11) NOT NULL,
  `LDataUtworzenia` datetime NOT NULL DEFAULT current_timestamp(),
  `LDataZmiany` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`LId`),
  UNIQUE KEY `uniq_sklep_typ` (`LSklId`,`LTyp`)
) ENGINE=InnoDB AUTO_INCREMENT=54 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `liczniki`
--

INSERT INTO `liczniki` (`LId`, `LSklId`, `LTyp`, `LWartosc`, `LDataUtworzenia`, `LDataZmiany`) VALUES (1,1,1,95,'2025-05-06 23:12:38','2025-05-06 23:12:38'),(25,3,1,95,'2025-05-07 00:32:22','2025-05-07 00:32:22'),(26,3,2,100,'2025-05-07 00:32:22','2025-05-07 00:32:22'),(27,3,3,100,'2025-05-07 00:32:22','2025-05-07 00:32:22'),(41,2,1,87,'2025-05-08 14:05:21','2025-05-08 14:05:21'),(42,2,2,100,'2025-05-08 14:05:21','2025-05-08 14:05:21'),(44,4,1,100,'2025-05-08 14:59:34','2025-05-08 14:59:34'),(45,4,2,100,'2025-05-08 14:59:34','2025-05-08 14:59:34'),(46,4,3,100,'2025-05-08 14:59:34','2025-05-08 14:59:34'),(47,5,1,100,'2025-05-08 14:59:50','2025-05-08 14:59:50'),(48,5,2,100,'2025-05-08 14:59:50','2025-05-08 14:59:50'),(49,5,3,100,'2025-05-08 14:59:50','2025-05-08 14:59:50'),(50,6,1,100,'2025-05-08 15:00:13','2025-05-08 15:00:13'),(51,6,2,100,'2025-05-08 15:00:13','2025-05-08 15:00:13'),(52,6,3,100,'2025-05-08 15:00:13','2025-05-08 15:00:13');

--
-- Table structure for table `rcp`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `rcp` (
  `RCPId` int(11) NOT NULL AUTO_INCREMENT,
  `RCPStartZmiany` datetime DEFAULT NULL,
  `RCPKoniecZmiany` datetime DEFAULT NULL,
  `RCPUzId` int(11) NOT NULL,
  PRIMARY KEY (`RCPId`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rcp`
--

INSERT INTO `rcp` (`RCPId`, `RCPStartZmiany`, `RCPKoniecZmiany`, `RCPUzId`) VALUES (1,'2025-04-24 09:19:29','2025-04-25 09:17:25',1),(2,'2025-04-25 09:26:59','2025-04-30 08:49:32',1),(3,'2025-05-04 20:14:39','2025-05-07 12:54:10',1),(4,'2025-05-07 12:54:11','2025-05-08 08:48:29',1),(5,'2025-05-08 14:03:34',NULL,1);

--
-- Table structure for table `rozmiary`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `rozmiary` (
  `RozId` int(11) NOT NULL AUTO_INCREMENT,
  `RozNazwa` varchar(255) NOT NULL,
  `RozPojemnosc` int(11) NOT NULL,
  `RozDataZmiany` datetime NOT NULL DEFAULT current_timestamp(),
  `RozStatus` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`RozId`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rozmiary`
--

INSERT INTO `rozmiary` (`RozId`, `RozNazwa`, `RozPojemnosc`, `RozDataZmiany`, `RozStatus`) VALUES (1,'Duży',90,'2025-04-24 09:01:01',1),(2,'Mega',100,'2025-04-24 09:01:06',1),(3,'Potężny',200,'2025-05-08 14:01:56',1);

--
-- Table structure for table `sklepy`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `sklepy` (
  `SklId` int(11) NOT NULL AUTO_INCREMENT,
  `SklNazwa` varchar(255) NOT NULL,
  `SklUlica` varchar(255) DEFAULT NULL,
  `SklNumer` varchar(255) DEFAULT NULL,
  `SklKod` varchar(255) DEFAULT NULL,
  `SklMiejscowosc` varchar(255) DEFAULT NULL,
  `SklPojemnosc` int(11) NOT NULL,
  `SklDataZmiany` datetime NOT NULL DEFAULT current_timestamp(),
  `SklStatus` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`SklId`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sklepy`
--

INSERT INTO `sklepy` (`SklId`, `SklNazwa`, `SklUlica`, `SklNumer`, `SklKod`, `SklMiejscowosc`, `SklPojemnosc`, `SklDataZmiany`, `SklStatus`) VALUES (1,'Sklep 1','Bolesława Prusa','33','30-117','Kraków',20,'2025-04-24 08:58:14',1),(2,'Sklep 2','','','','',124124,'2025-04-24 15:05:02',1),(3,'Lalalala','','','','',10,'2025-05-07 00:32:22',1),(4,'lalalalalalalalalalalalalalal','','','','',1,'2025-05-08 14:59:34',1),(5,'123','','','','',123,'2025-05-08 14:59:50',1),(6,'12345','','','','',123,'2025-05-08 15:00:13',1);

--
-- Table structure for table `smaki`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `smaki` (
  `SmkId` int(11) NOT NULL AUTO_INCREMENT,
  `SmkNazwa` varchar(255) NOT NULL,
  `SmkKolor` varchar(255) DEFAULT NULL,
  `SmkTekstKolor` varchar(255) DEFAULT NULL,
  `SmkStatus` tinyint(1) NOT NULL DEFAULT 1,
  `SmkTowId` int(11) NOT NULL DEFAULT 1,
  `SmkDataZmiany` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`SmkId`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `smaki`
--

INSERT INTO `smaki` (`SmkId`, `SmkNazwa`, `SmkKolor`, `SmkTekstKolor`, `SmkStatus`, `SmkTowId`, `SmkDataZmiany`) VALUES (1,'Czekolada','#570000','#ffffff',1,1,'2025-04-24 09:00:40'),(2,'Truskawka','#ff0000','#ffffff',1,1,'2025-04-24 09:00:48'),(3,'Wanilia','#fff0b8','#000000',1,1,'2025-05-07 12:49:45'),(4,'Guma Balonowa','#00fbff','#ff00ea',1,1,'2025-05-07 12:49:57'),(5,'Śmietanka','#ffffff','#000000',1,1,'2025-05-07 12:50:12'),(6,'Jagoda','#9a47ff','#ffffff',1,1,'2025-05-07 12:50:30'),(7,'Czekolada Dubajska','#750000','#74c200',1,8,'2025-05-07 12:50:50'),(8,'Kinder Niespodzianka','#fd4e4e','#ffffff',1,1,'2025-05-07 12:51:12'),(9,'Winogrono','#74c87a','#000000',1,1,'2025-05-07 12:51:32'),(10,'Mięta','#42ffa7','#000000',1,1,'2025-05-07 12:51:49');

--
-- Table structure for table `towary`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `towary` (
  `TowId` int(11) NOT NULL AUTO_INCREMENT,
  `TowNazwa` varchar(255) NOT NULL,
  `TowCenaId` int(11) NOT NULL,
  `TowDataZmiany` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`TowId`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `towary`
--

INSERT INTO `towary` (`TowId`, `TowNazwa`, `TowCenaId`, `TowDataZmiany`) VALUES (1,'Lody Rzemieślnicze',1,'2025-04-24 09:20:03'),(2,'Lody Włoskie Małe',2,'2025-04-24 09:20:03'),(3,'Lody Włoskie Duże',3,'2025-04-24 09:20:03'),(4,'Kawa Mrożona',4,'2025-04-24 09:20:03'),(5,'Granita',5,'2025-04-24 09:20:03'),(6,'Polewa/Posypka',6,'2025-04-24 09:20:03'),(7,'Bita Śmietana',7,'2025-04-24 09:20:03'),(8,'Czekolada Dubajska',8,'2025-05-08 14:42:44');

--
-- Table structure for table `ulozenie`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `ulozenie` (
  `UId` int(11) NOT NULL AUTO_INCREMENT,
  `UKuw1Id` int(11) DEFAULT NULL,
  `UKuw2Id` int(11) DEFAULT NULL,
  `UKuw3Id` int(11) DEFAULT NULL,
  `UKuw4Id` int(11) DEFAULT NULL,
  `UKuw5Id` int(11) DEFAULT NULL,
  `UKuw6Id` int(11) DEFAULT NULL,
  `UKuw7Id` int(11) DEFAULT NULL,
  `UKuw8Id` int(11) DEFAULT NULL,
  `UKuw9Id` int(11) DEFAULT NULL,
  `UKuw10Id` int(11) DEFAULT NULL,
  `USklId` int(11) NOT NULL,
  `UDataZmiany` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`UId`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ulozenie`
--

INSERT INTO `ulozenie` (`UId`, `UKuw1Id`, `UKuw2Id`, `UKuw3Id`, `UKuw4Id`, `UKuw5Id`, `UKuw6Id`, `UKuw7Id`, `UKuw8Id`, `UKuw9Id`, `UKuw10Id`, `USklId`, `UDataZmiany`) VALUES (1,9,11,12,13,14,15,16,17,18,19,1,'2025-05-08 15:15:52'),(2,NULL,NULL,NULL,26,2,NULL,NULL,NULL,NULL,NULL,2,'2025-05-08 15:40:15'),(3,NULL,NULL,NULL,NULL,24,NULL,NULL,NULL,NULL,NULL,3,'2025-05-08 14:03:38'),(4,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,4,'2025-05-08 14:59:34'),(5,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,5,'2025-05-08 14:59:50'),(6,NULL,NULL,NULL,NULL,23,NULL,NULL,NULL,NULL,NULL,6,'2025-05-08 15:15:39');

--
-- Table structure for table `uzytkownicy`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `uzytkownicy` (
  `UzId` int(11) NOT NULL AUTO_INCREMENT,
  `UzImie` varchar(255) NOT NULL,
  `UzNazwisko` varchar(255) NOT NULL,
  `UzLogin` varchar(255) DEFAULT NULL,
  `UzHaslo` varchar(255) DEFAULT NULL,
  `UzPIN` varchar(255) DEFAULT NULL,
  `UzStatus` tinyint(1) NOT NULL DEFAULT 1,
  `UzStawkaGodzinowa` float DEFAULT 0,
  `UzDataZmiany` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`UzId`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `uzytkownicy`
--

INSERT INTO `uzytkownicy` (`UzId`, `UzImie`, `UzNazwisko`, `UzLogin`, `UzHaslo`, `UzPIN`, `UzStatus`, `UzStawkaGodzinowa`, `UzDataZmiany`) VALUES (1,'Jan','Kowalski','jk','$2b$10$2kkgalc9FPrUi3uoctqJvu5xadRDEdWFMrPy6jVxeNpZmunb2uBPa','$2b$10$zFrEkSlHgm62AH.vHyG.hO4wvda9HSdadJuHXHLrTXmEmF30lknuS',1,28.5,'2025-05-07 13:16:46'),(2,'Mateusz','Gancarz','mati','$2b$10$BjxRHNKl.xxbSVdHcgZmzu/qOtXd.6qbgVZNIZHJeVh1fXWD5PX/6','$2b$10$rU3HFJXMIuoctL4uZKQl0ODO3wCD9tL4h/ILIeByAMfo1laO9pjA6',1,NULL,'2025-04-25 11:18:30'),(3,'Karol','Niebieski','kk','$2b$10$y0uk5tjoZpXGP9HM15amlOVZSBu3lpmDSvweoakpUDPWaDve05Lmm','$2b$10$mDh.bd4PavHM8bAcqHF9k.6GuQdeRYyl2KL/0CWb.QE7D5U4qZOhm',1,NULL,'2025-05-08 14:03:11');

--
-- Table structure for table `uzytkownicysklep`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `uzytkownicysklep` (
  `UzSklId` int(11) NOT NULL AUTO_INCREMENT,
  `UzSklUzId` int(11) NOT NULL,
  `UzSklSklId` int(11) NOT NULL,
  PRIMARY KEY (`UzSklId`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `uzytkownicysklep`
--

INSERT INTO `uzytkownicysklep` (`UzSklId`, `UzSklUzId`, `UzSklSklId`) VALUES (1,1,1),(2,1,2),(3,1,3),(4,2,3),(5,3,2);

--
-- Table structure for table `zamowienia`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `zamowienia` (
  `ZamId` int(11) NOT NULL AUTO_INCREMENT,
  `ZamNr` varchar(255) NOT NULL,
  `ZamAutorId` int(11) NOT NULL,
  `ZamSklId` int(11) NOT NULL,
  `ZamDokTyp` int(11) NOT NULL,
  `ZamDataUtworzenia` datetime NOT NULL DEFAULT current_timestamp(),
  `ZamDataZmiany` datetime NOT NULL DEFAULT current_timestamp(),
  `ZamStatus` tinyint(1) NOT NULL DEFAULT 1,
  `ZamZrealizowano` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`ZamId`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `zamowienia`
--

INSERT INTO `zamowienia` (`ZamId`, `ZamNr`, `ZamAutorId`, `ZamSklId`, `ZamDokTyp`, `ZamDataUtworzenia`, `ZamDataZmiany`, `ZamStatus`, `ZamZrealizowano`) VALUES (1,'ZAM/1/2025/1',1,1,2,'2025-05-06 00:15:55','2025-05-06 00:15:55',1,1),(2,'ZAM/2/2025/1',1,1,2,'2025-05-06 00:16:39','2025-05-06 00:16:39',0,1),(3,'ZAM/1/2025/2',1,2,2,'2025-05-06 00:30:33','2025-05-06 00:30:33',1,1),(4,'ZAM/3/2025/1',1,1,2,'2025-05-06 00:54:16','2025-05-06 00:54:16',1,1),(5,'ZAM/1/2025/1',1,1,2,'2025-05-07 12:54:18','2025-05-07 12:54:18',1,1),(6,'ZAM/2/2025/1',1,1,2,'2025-05-07 13:39:13','2025-05-07 13:39:13',1,1),(7,'ZAM/3/2025/1',1,1,2,'2025-05-07 13:39:41','2025-05-07 13:39:41',1,1),(8,'ZAM/4/2025/1',1,1,2,'2025-05-07 13:39:44','2025-05-07 13:39:44',1,1),(9,'ZAM/5/2025/1',1,1,2,'2025-05-07 13:39:48','2025-05-07 13:39:48',1,1),(10,'ZAM/6/2025/1',1,1,2,'2025-05-07 13:39:51','2025-05-07 13:39:51',1,1),(11,'ZAM/7/2025/1',1,1,2,'2025-05-07 13:39:53','2025-05-07 13:39:53',1,1),(12,'ZAM/8/2025/1',1,1,2,'2025-05-08 08:28:43','2025-05-08 08:28:43',1,0);

--
-- Table structure for table `zamowieniapozycje`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `zamowieniapozycje` (
  `ZamPozId` int(11) NOT NULL AUTO_INCREMENT,
  `ZamPozZamId` int(11) NOT NULL,
  `ZamPozTowar` varchar(255) NOT NULL,
  `ZamPozOpis` varchar(255) DEFAULT NULL,
  `ZamPozIsSmak` tinyint(1) NOT NULL,
  PRIMARY KEY (`ZamPozId`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `zamowieniapozycje`
--

INSERT INTO `zamowieniapozycje` (`ZamPozId`, `ZamPozZamId`, `ZamPozTowar`, `ZamPozOpis`, `ZamPozIsSmak`) VALUES (1,1,'Truskawka','0',1),(2,2,'Bita Śmietana','',0),(3,2,'Baza do l. włoskich','truskawka',0),(4,3,'Kubki Granita','',0),(5,3,'Kubki Granita','',0),(6,3,'Kubki Granita','',0),(7,4,'Baza do l. włoskich','czekolada',0),(8,4,'Truskawka','0',1),(9,4,'Czekolada','2',1),(10,4,'Granita','owocowa',0),(11,4,'Kubki Granita','',0),(12,4,'Mleko','',0),(13,4,'Patyczki','',0),(14,4,'Ręcznik Papierowy','',0),(15,4,'Rękawiczki','',0),(16,4,'Serwetki','',0),(17,5,'Czekolada','1',1),(18,6,'Bita Śmietana','',0),(19,6,'Czekolada Dubajska','0',1),(20,6,'Guma Balonowa','0',1),(21,7,'Cukier','',0),(22,8,'Czekolada Dubajska','0',1),(23,8,'Guma Balonowa','0',1),(24,9,'Baza do l. włoskich','123',0),(25,9,'Cukier','',0),(26,9,'Bita Śmietana','',0),(27,10,'Śmietanka','0',1),(28,10,'Truskawka','0',1),(29,11,'Śmietanka','0',1),(30,11,'Truskawka','0',1),(31,12,'Bita Śmietana','',0);

--
-- Dumping routines for database 'lody_lacko'
--
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'IGNORE_SPACE,STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `rejestruj_zmiane`(IN user_id INT)
BEGIN
        DECLARE v_last_id INT;
        DECLARE v_end_time DATETIME;
        
        SELECT RCPId, RCPKoniecZmiany INTO v_last_id, v_end_time
        FROM RCP 
        WHERE RCPUzId = user_id
        ORDER BY RCPStartZmiany DESC 
        LIMIT 1;
        
        IF v_last_id IS NULL OR v_end_time IS NOT NULL THEN
            INSERT INTO RCP (RCPUzId, RCPStartZmiany, RCPKoniecZmiany)
            VALUES (user_id, NOW(), NULL);
        ELSE
            UPDATE RCP
            SET RCPKoniecZmiany = NOW()
            WHERE RCPId = v_last_id;
        END IF;
    END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-05-08 15:56:27
